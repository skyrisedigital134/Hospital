# New Prem Ji Hospital — Website

A multi-page static website (HTML/CSS/JS only — no build step needed).

## Structure
```
├── index.html        Home page
├── about.html         About Us page
├── services.html       Services page
├── doctors.html        Doctors page
├── contact.html        Contact page
├── css/style.css       All styling
├── js/main.js          Mobile nav + hero slider
└── images/             All images (placeholders included)
```

## Images to replace
All images are placeholders — swap them out with real files using the **same filenames** and everything will update automatically:
- `images/hospitallogo.png` — hospital logo
- `images/image1.png`, `image2.png`, `image3.png` — homepage hero slider
- `images/image4.png`, `image5.png` — about/welcome section images
- `images/doctor1.png`, `images/doctor2.png` — doctor photos

## Placeholders to update with real info
- Phone numbers, email, and address (top bar, footer, contact page)
- Doctor names, qualifications and specialties (`doctors.html`, `index.html`)
- Google Map embed on `contact.html` (replace the `src` in the `iframe` with your real location)
- Contact form `action="#"` — connect to a form backend (e.g. Formspree, Google Forms, or your own server) to actually receive submissions

## Deploying with GitHub Pages
1. Create a new GitHub repository and push all these files to it (keep the folder structure as-is).
2. Go to **Settings → Pages** in your repo.
3. Under "Build and deployment", set Source to **Deploy from a branch**, choose the `main` branch and `/ (root)` folder.
4. Save — your site will be live at `https://<your-username>.github.io/<repo-name>/` within a minute or two.
